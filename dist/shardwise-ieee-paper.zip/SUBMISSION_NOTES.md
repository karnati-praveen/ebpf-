# Submission and author audit

The paper retains Anonymous Authors for the user to audit later. Upload the PDF
through the selected conference's submission system; the ZIP is an editable
source package, not an automatic submission. For CCGrid 2027, the current call
requires double-blind IEEE conference papers of no more than 10 pages including
references. Verify the chosen track and current rules before uploading.
Official call: https://hpcclab.org/ccgrid27-call-for-papers/

Actual CPU execution images and the CPU/GPU illustration have distinct captions.
The latter assigns CPU 8 / GPU 16 layers and is explicitly not measured GPU
execution. The evidence and remaining scientific limits are described in the
paper and READINESS.md. Review artifact anonymity and any disclosure requirements
referenced by the conference call; do not upload author-identifying demo
provenance as anonymous supplementary material without an anonymity audit.

The combined archive's demo is a separately versioned application artifact.
System-wide installation was not tested; launching its extracted payload was.
